import 'package:flutter/material.dart';
import '../../core/app_icons.dart';
import '../../core/widgets/buttons.dart';
import '../../core/widgets/pin_dots.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_text_styles.dart';
import 'biometric_prompt_screen.dart';

/// Second half of PIN setup — re-enter the PIN to confirm it matches.
class ConfirmPinScreen extends StatefulWidget {
  const ConfirmPinScreen({super.key, required this.originalPin});

  final String originalPin;

  @override
  State<ConfirmPinScreen> createState() => _ConfirmPinScreenState();
}

class _ConfirmPinScreenState extends State<ConfirmPinScreen> {
  String _pin = '';
  bool _mismatch = false;

  void _onKey(String digit) {
    if (_pin.length >= 4 || _mismatch) return;
    setState(() => _pin += digit);
    if (_pin.length == 4) {
      if (_pin == widget.originalPin) {
        Future.delayed(const Duration(milliseconds: 250), () {
          if (mounted) {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const BiometricPromptScreen()),
            );
          }
        });
      } else {
        setState(() => _mismatch = true);
        Future.delayed(const Duration(milliseconds: 900), () {
          if (mounted) {
            setState(() {
              _mismatch = false;
              _pin = '';
            });
          }
        });
      }
    }
  }

  void _onBackspace() {
    if (_pin.isEmpty || _mismatch) return;
    setState(() => _pin = _pin.substring(0, _pin.length - 1));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.page,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 8),
              IconCircleButton(
                icon: AppIcons.chevronLeft,
                onTap: () => Navigator.of(context).pop(),
              ),
              const SizedBox(height: 24),
              const Text('Confirm your PIN', style: AppText.pageTitle),
              const SizedBox(height: 8),
              const Text('Enter it again to confirm.', style: AppText.bodyMuted),
              const SizedBox(height: 40),
              Center(child: PinDots(length: 4, filled: _pin.length)),
              const SizedBox(height: 16),
              SizedBox(
                height: 18,
                child: _mismatch
                    ? const Center(
                        child: Text(
                          "PINs didn't match — try again",
                          style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                            color: AppColors.loss,
                          ),
                        ),
                      )
                    : null,
              ),
              const SizedBox(height: 24),
              NumericKeypad(onKey: _onKey, onBackspace: _onBackspace),
            ],
          ),
        ),
      ),
    );
  }
}
